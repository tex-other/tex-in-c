#include <setjmp.h>
extern unsigned char nameoffile[filenamesize];
extern ASCIIcode buffer[];
extern short last;
extern short first;
extern short maxbufstack;
extern jmp_buf _JLfinalend;
extern strnumber formatident;
extern instaterecord curinput;
extern ASCIIcode xord[256];

