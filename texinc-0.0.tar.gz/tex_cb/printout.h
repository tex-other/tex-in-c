extern void printparam(long n);
extern void printcmdchr(quarterword cmd, halfword chrcode);

/* Imports */
/*
extern void print(long s);
extern void printesc(strnumber s);
extern void printhex(long n);
extern void printint(long n);
extern void printlengthparam(long n);
extern void printscaled(long s);
extern void printsize(long s);
extern void printskipparam(long n);
extern void printstyle(long c);
*/

extern scaled fontsize[fontmax - fontbase + 1];
extern scaled fontdsize[fontmax - fontbase + 1];
extern strnumber fontname[fontmax - fontbase + 1];
